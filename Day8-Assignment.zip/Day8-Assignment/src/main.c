#include "hal/hal_gpio.h"



int main(void) {
	hal_gpio_init();
	hal_gpio_set_led(0);
    _delay_ms(50);
	while (1) {
			void hal_gpio_digital_write() {
		hal_gpio_handle_button();
	}
	hal_gpio_digital_write();
	

	}
}