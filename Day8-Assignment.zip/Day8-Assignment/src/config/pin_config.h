
#ifndef HAL_GPIO

#define led_pin PD7
#define button_pin PB5
#define led_port &PORTD
#define button_port &PINB
#define led_ddr &DDRD
#define button_ddr &DDRB

#endif 
