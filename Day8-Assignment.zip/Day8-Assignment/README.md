# GPIO Button and LED Control

This code controls an LED using a button with four modes:
at start LED is off then below operation occur on click on button

1. LED slow blink
2. LED fast blink
3. LED ON
4. LED OFF

Each button press cycles to the next mode. The code uses software debouncing to ensure only one mode change per press.